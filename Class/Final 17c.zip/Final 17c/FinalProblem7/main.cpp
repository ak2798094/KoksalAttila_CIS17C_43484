/** 
 * @file:   main.cpp
 * @author: Attila Koksal
 * @date: Created on June 11, 2022, 5:45 PM
 * Purpose:  Problem 7
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout<<"Problem 7"<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}